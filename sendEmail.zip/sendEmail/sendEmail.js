var mailer = require('nodemailer');

var mailConfig = mailer.createTransport({
    service:'gmail',
    auth:{
        user:'nikhil.shah2008@gmail.com',
        pass:''
    }
});

var recieverInformation = {
    from: 'nikhil.shah2008@gmail.com',
    to:'nikhilshah.net@hotmail.com',
    cc:'nikhilshah@rps.com',
    subject:'Another Email from Node Trainer',
    text:'Hi this is the second email, as it is free I will keep sending this emails, one more time'
};

mailConfig.sendMail(recieverInformation,function(err,succes){
    if(err){console.log(err.message);}
    else{ console.log('email sent successfully'); }
})









