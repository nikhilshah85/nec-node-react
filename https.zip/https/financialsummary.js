var httpsObj = require('https');
var certFiles = require('fs');


var certificates = {
    key:certFiles.readFileSync('firstprivatekey.pem'),
    cert:certFiles.readFileSync('mycertificate.pem')
};

var server = httpsObj.createServer(certificates,function(req,res){
    res.write('<h1> Welcome to secured page </h1>');

    console.log('one client is connected');
    res.end();
}).listen(8080);
console.log('server is running');