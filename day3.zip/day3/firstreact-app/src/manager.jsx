import React from 'react';
import './manager.css'
class Manager extends React.Component
{

    managerName = 'Sahil';
    managerType = 'Finance Manager'
    render(){
        return(
            <div>
                <h1> Manager Component</h1>
                <p> {this.managerName} </p>
                <p> {this.managerType} </p>
            </div>)
    }

}

export default Manager;