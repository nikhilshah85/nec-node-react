import React from 'react';
import './developer.css'
class Developer extends React.Component
{

    managerName = 'Rohan';
    managerType = 'Project Manager'
    render(){
        return(
            <div>
                <h1> Developer Component</h1>
                <p> {this.managerName} </p>
                <p> {this.managerType} </p>
            </div>)
    }

}

export default Developer;