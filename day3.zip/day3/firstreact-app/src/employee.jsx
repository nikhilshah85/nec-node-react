import React from 'react';
import Developer from './devloper';
import Manager from './manager'
class Employee extends React.Component
{


     empNo= 101;
     empName = "Nikhil";
    render(){
        return(<div>
                <h1> I am an Employee Component</h1>
                    <input type="text" placeholder="Enter Employee Number"/>

                    <h1> { this.empNo  } : { this.empName } </h1>

                    <hr/>

                    <Manager></Manager>
                    <Developer></Developer>
            </div>)
    }

}

export default Employee;

