import logo from './logo.svg';
import './App.css';
import Employee from  './employee';
function App() {

  var myName = 'Nikhil Shah';
  var myCity = 'Mumbai';
  var myAge = 30;
  var qty = 5;
  var price = 15;
  var discount = 2;

  var friends =['Karan','Rahul','Rahil','Sahil','Priya','Riya'];
  var techList = ['React','Redux','.Net','Core','SQL Server', 'Mongo','Angular','TypeScript']

  var product ={pId:101,pName:'Pepsi',pPrice:50,pCategory:'Soft-Drink' }



  var stockInfo=[{stockId:101,stockName:'Reliance',stockPurchasePrice:1800,stockCurrentPrice:2000,qty:100},
  {stockId:101,stockName:'Eicher',stockPurchasePrice:2500,stockCurrentPrice:1100,qty:100},
  {stockId:102,stockName:'Wipro',stockPurchasePrice:600,stockCurrentPrice:800,qty:100},
  {stockId:103,stockName:'Infosys',stockPurchasePrice:900,stockCurrentPrice:1900,qty:100},
  {stockId:104,stockName:'TCS',stockPurchasePrice:2500,stockCurrentPrice:3000,qty:100},
  {stockId:105,stockName:'SBI',stockPurchasePrice:600,stockCurrentPrice:500,qty:100},
  {stockId:106,stockName:'Cipla',stockPurchasePrice:800,stockCurrentPrice:1200,qty:100},
  {stockId:107,stockName:'Maruti',stockPurchasePrice:4000,stockCurrentPrice:8000,qty:100},
  {stockId:108,stockName:'Ford',stockPurchasePrice:1200,stockCurrentPrice:900,qty:100},
  {stockId:109,stockName:'Fortis',stockPurchasePrice:900,stockCurrentPrice:2300,qty:100},
  {stockId:110,stockName:'Devis',stockPurchasePrice:1900,stockCurrentPrice:1500,qty:100},
  {stockId:111,stockName:'Ranbaxy',stockPurchasePrice:400,stockCurrentPrice:1200,qty:100}]

  return (
    <div>
       <h1> Hello React APP</h1>

{/* display sime variables */}
       {/* <h3> My Name is : { myName }, I am from { myCity }</h3>
       <h4> My Age Today : { myAge }</h4>
    <h4> My Age in 2031 Will be : { myAge + 10}</h4>
    <h3> Price Value : { (qty * price) * discount / 100 } </h3> */}

{/* display simple Array  */}
    {/* <ul>
        { friends.map((val)=>  <li> Hello : {val} </li>    ) }
    </ul>
    <hr/>
    <ol>
        { techList.map( (t)=> <li> {t}  <input type="checkbox"/>  </li> ) }
    </ol> */}

     {/* <h1> Product Details </h1>
     <hr/>

        <h3>Product Id: { product.pId  } </h3>
        <h3>Product Name: { product.pName  } </h3>
        <h3>Product Category: { product.pCategory  } </h3>
        <h3>Product Price: { product.pPrice  } </h3>*/}
    {/* <table border="1" className="table table-stripped">
          { stockInfo.map( (s) => <tr> 
                                    <td> {s.stockId} </td>
                                    <td> {s.stockName} </td>
                                    <td> {s.stockPurchasePrice} </td>
                                    <td> {s.stockCurrentPrice} </td>
                                    <td> {s.qty} </td>
                                    <td> {s.qty * s.stockPurchasePrice} </td>
                                    <td> {s.qty * s.stockCurrentPrice} </td>
                                    <td> {s.qty*s.stockPurchasePrice - s.qty*s.stockCurrentPrice} </td>
                                    <td> <button className="btn btn-primary" >Add</button>  </td>
                                    <td> <button className="btn btn-danger">Sell</button>  </td>
                                    

                          </tr> ) }
    </table> */}

      <h1> Welcome to React </h1>

      <Employee></Employee>

     

    </div> 
  )
}

export default App;
;