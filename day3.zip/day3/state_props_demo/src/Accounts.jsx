import React from 'react';


class Accounts extends React.Component
{
  
    render(){
        return(
            <div>
                <hr/>
                <h4> Developer is: {this.props.developer} </h4>
                <ul>
                    { this.props.accTypes.map( (a)=> <li> {a}  </li> ) }
                </ul>
            </div>
        )
    }

}

export default Accounts;