import React from 'react';
import Accounts from './Accounts'

class Client extends React.Component
{

    accountTypes = ['Savings','Current','PF','Credit']
    render(){
        return(
            <div>
                <h1> { this.props.applicationName } </h1>
                <h1> { this.props.developedBy } </h1>
                <h1> { this.props.strength } </h1>

            <Accounts accTypes={this.accountTypes} developer ={this.props.developedBy}></Accounts>
            </div>
        )
    }

}

export default Client;