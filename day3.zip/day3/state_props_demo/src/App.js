import logo from './logo.svg';
import './App.css';
import Client from './client';


function App() {


  var appName = "First React Applcition";
  var developer = "Anish";
  var teamSize = 10;
  var profitMargin=20;
  
  return (
    <div>
      <Client applicationName={appName}
              developedBy={developer}
              strength={teamSize}></Client>
    </div>
  );
}

export default App;
