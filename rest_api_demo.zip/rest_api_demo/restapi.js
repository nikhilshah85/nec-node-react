var myExpress = require('express');
var app = myExpress();

contactsList =[];

app.get('/contactlist',function(req,res) {
    
    contact1 = {name:'Rahul',mobile:89565656,email:'rahul@gmail.com'};
    contact2 = {name:'Mansi',mobile:6396,email:'rahul@gmail.com',picture:''};
    contact3 = {name:'Priya',mobile:1236,email:'rahul@gmail.com',emergencyContact:{mother:5623,father:7854,bestFriend:'Sahil' }};
    contact4 = {name:'Sahil',mobile:896523,email:'rahul@gmail.com'};
    contact5 = {name:'Mark',mobile:2525};
    contactsList = [contact1,contact2,contact3,contact4,contact5];
    res.json(contactsList);
})

app.listen(6363);
console.log('REST API ContactList is up and running ');