var express = require('express');
var app = express();

let productList = [];


app.get('/getproductlist',function(req,res) {
    
    if(productList.length == 0)
    {
        product1 = {pId:101, pName:'Pepsi',pCategory:'Soft-Drink',pPrice:50};
        product2 = {pId:102, pName:'Coke',pCategory:'Soft-Drink',pPrice:80};
        product3 = {pId:103, pName:'Maggie',pCategory:'Fast-Food',pPrice:25};
        product4 = {pId:104, pName:'Lays',pCategory:'Fast-Food',pPrice:120};
        product5 = {pId:105, pName:'Sandwitch',pCategory:'Fast-Food',pPrice:180};
        productList=[product1,product2,product3,product4,product5];
    }
    res.send(productList);
})

app.post('/addproduct',function(req,res) {
    product5 = {pId:106, pName:'Appy',pCategory:'Cold-Drink',pPrice:30};
    productList.push(product5);

    console.log('New Post Request is recieved');
    res.send(productList);
    res.end();
})
app.put('/updateproduct',function(req,res) {
    
    productList[3].pCategory = 'Junk-Food';
    for (let index = 0; index < productList.length; index++) {
        productList[index].pPrice = productList[index].pPrice + 20;        
    }  
    console.log('Products Updated');
    res.send(productList);
    res.end();
})
app.delete('/deleteproduct',function(req,res) {
    productList.pop();
    console.log('Product Deleted');
    res.send(productList);
    res.end();
})

app.get('/getbyid',function(req,res) {
    productSearch = productList[3];
    res.send(productSearch);
    res.end();
})

app.listen(8877);
console.log('Product API is running');