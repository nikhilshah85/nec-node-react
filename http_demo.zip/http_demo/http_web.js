var httpObj = require('http');

httpObj.createServer(function(req,res) {
    res.writeHead(200,{'Content-Type':'text/html'});

    res.write('<h1> This is from VS Code Development </h1>');

    res.end();
}).listen(8585);

console.log('Server listening on 8585');