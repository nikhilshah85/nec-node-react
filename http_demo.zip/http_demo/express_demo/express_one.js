var myExpress = require('express');
var myApp = myExpress();

myApp.get('/',function(req,res) {
    res.sendFile('/default.html',{root:__dirname});
})

myApp.get('/home',function(req,res) {
    // res.send('Welcome to Home Page');
    res.sendFile('/home.html',{root:__dirname});
});

myApp.get('/about',function(req,res) {
    res.sendFile('/about.html',{root:__dirname});
});

myApp.get('/contact',function(req,res) {
    res.sendFile('/contact.html',{root:__dirname});
});


myApp.listen(5656);
console.log('Server listning on 5656');

