var app = require('express')();
var http = require('http').Server(app);
var http2 = require('http');
var io = require('socket.io')(http2);
var ngrok = require('ngrok');


const port = 8080;
const server = http2.createServer((req, res) => {

  app.get('/', function(req, res){
    res.sendFile(__dirname + '/index.html');
  });
  
  io.on('connection', function(socket){
    socket.on('chat message', function(msg){
      io.emit('chat message',msg);
    });
  });
    res.end('Hello, World! welcome to NGRok test');
});

server.listen(port, (err) => {
    if (err) return console.log(`Something bad happened: ${err}`);
    console.log(`Node.js server listening on ${port}`);


    
    ngrok.connect(port, function (err, url) {
        console.log(`Node.js local server is publicly-accessible at ${url}`);
    });

});





// http.listen(8080, function(){
//   console.log('listening on *:8080');
// });

// const server = http2.createServer((req,res)=>{
//   res.end("Hello World");
// });


// server.listen(port, function(){
//     console.log('listening on *:8080');

//     // ng.connect(port,function(err,url){
//     //   console.log('Server listening to public on :'  + url);
//     // })
//   });
//   // ng.connect(port,function(err,url){
//   //   console.log('Server listening to public on :'  + url);
//   // })
//   const url = ng.connect(9090);
//   console.log(url);

 
