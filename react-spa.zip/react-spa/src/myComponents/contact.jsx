import React from 'react'

class Contact extends React.Component
{
    render(){
        return(<div>
            <h1> Welcome To Contact us Page </h1>

            
            <h2> Contact No: { this.props.contactInfo.contactNo}</h2>
            <h2> Email Address: { this.props.contactInfo.email}</h2>
            <h2> Office No :{ this.props.contactInfo.office}</h2>
        </div>)
    }
}

export default Contact;