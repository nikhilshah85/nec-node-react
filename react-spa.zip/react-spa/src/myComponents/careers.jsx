import React from 'react'

class Careers extends React.Component
{
    render(){
        return(<div>
            <h1>Current Openings </h1>

            <ul>
                {this.props.openPositions.map((p,i)=> <li> {p} <a href="#"> Apply </a> </li> )}
            </ul>
        </div>)
    }
}

export default Careers;