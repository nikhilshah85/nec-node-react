import React from 'react'

class News extends React.Component
{
    render(){
        return(<div>
            <h1> Todays News </h1>

         <h1>American democracy is about to show if it can save itself</h1>

         <p>
         Such a premise would have been considered absurd through much of history. But since Trump left office after destroying the tradition of peaceful transfers of power in a failed attempt to steal the 2020 election, it has become clear that his insurrectionism was only the first battle in a longer political war as his allies tout ridiculous fantasies about returning him to power to applause and online acclaim.
The mechanisms of American institutions that barely survived Trump's attempt to illegally stay in power are still being manipulated by Republicans to make the country less democratic. The GOP's efforts to stack the electoral decks are staggeringly broad. From Georgia to Arizona and Florida and in many other states, Republicans are mobilizing behind efforts to shorten voting hours, crack down on early and mail-in balloting and to throw out legitimate ballots -- all under a banner of election security.
While Trump may be banned from Twitter, he sends out daily statements pulsating with lies and incitement that percolate among supporters on social media. The ex-President's planned resumption of rallies next month will bring that anti-democratic stream of falsehood to a wider audience.
         </p>
        </div>)
    }
}

export default News;