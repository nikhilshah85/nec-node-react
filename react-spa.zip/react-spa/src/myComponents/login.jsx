import React from 'react'

class Login extends React.Component
{
    render(){
        return(<div>
            <h1> Welcome Login</h1>

            <input type="text" placeholder="User Name" className="form-control"/>
            <input type="password" placeholder="Password" className="form-control"/>
            <button className="btn btn-primary"> Login </button>
            <button className="btn btn-warning"> Reset </button>
        </div>)
    }
}

export default Login;