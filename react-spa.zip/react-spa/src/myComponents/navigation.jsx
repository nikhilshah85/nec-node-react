import React, {Component } from "react";
import {Link} from 'react-router-dom';


class Navigation extends React.Component
{
    render(){
        return(<nav>
            <ul className="nav nav-justified">
                <Link to="/" role="presentation" className="active"> Home | </Link>
                <Link to="/about" role="presentation">  About Us | </Link>
                <Link to="/contact" role="presentation">  Contact Us | </Link>
                <Link to="/career" role="presentation">  Careers Us | </Link>
                <Link to="/login" role="presentation">  Login | </Link>
                <Link to="/news" role="presentation">  Latest New | </Link>
                <Link to="/addopenings" role="presentation">  Add Openings | </Link>
            </ul>
        </nav>)
    }
}

export default Navigation;