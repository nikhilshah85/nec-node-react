import React from 'react'

class Home extends React.Component
{
    render(){
        return(<div>
            <h1> Welcome Home</h1>

            <h3> Todays Date : { this.props.designedOn} </h3>
            <h3> Developed by : { this.props.developer} </h3>

            <p> Welcome to the Home and this is the landing page </p>

            <p> some iamge here</p>

            <p> some Video here</p>
        </div>)
    }
}

export default Home;