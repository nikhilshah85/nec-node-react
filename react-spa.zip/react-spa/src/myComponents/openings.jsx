import React from 'react'
import ReactDOM from "react-dom";

class Openings extends React.Component
{

    constructor(){
        super();
        this.addNewPosition = this.addNewPosition.bind(this);
    }


    addNewPosition()
    {
        let newPosition = ReactDOM.findDOMNode(this.refs.refAddNewPosition).value;
        this.props.openings.push(newPosition);
        console.log(this.props.openings);
    }
    render(){
        return(<div>
            <h1> Add new Openings</h1>

            <input type="text" placeholder="Type a new Position" ref="refAddNewPosition"/>
            <button className="btn btn-primary" onClick={this.addNewPosition}> Add To Careers </button>
         
        </div>)
    }
}

export default Openings;