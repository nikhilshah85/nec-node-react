import React from 'react'
import Contact from './myComponents/contact';
import Navigation from './myComponents/navigation';
import {BrowserRouter as Router,Switch,Route} from 'react-router-dom';
import Home from './myComponents/home';
import About from './myComponents/about';
import Careers from './myComponents/careers';
import Login from './myComponents/login';
import  './App.css'
import News from './myComponents/news';
import Openings from './myComponents/openings';
class App extends React.Component
{

constructor(){
  super();

  this.state ={
    date : '02/06/2021',
    developedBy :'Nikhil Shah',
    contactInfo:{contactNo:5656656, email:'nikhilshah@rps.com', office:5656565 },
    openings:['Developer','Designer','Cloud Admin'],
    users:[ {userName:'Nikhil',pass:'pass@123'}, {userName:'Priya',pass:'pass@123'}, {userName:'Kiran',pass:'pass@123'}, {userName:'Nikhil',pass:'pass@123'},
                  {user:'Umesh', pass:'pass1234'}]
  }
}


    render(){
        return(<div>
            <h1>Welcome to My Organization Name</h1>

          <Router>
            <Navigation></Navigation>
          <Switch>
            <div className="myDiv">
                <Route path="/" exact render={ ()=> <Home  designedOn={ this.state.date }
                                                      developer={this.state.developedBy}/> } />

                <Route path="/about" component={About}/>
                <Route path="/contact" render={ ()=> <Contact contactInfo={this.state.contactInfo}/> } />
                <Route path="/career" render={()=> <Careers openPositions={this.state.openings}/>  }/>
                <Route path="/login" component={Login}/>
                <Route path="/news" component={News}/>
                <Route path="/addopenings"   render={ ()=> <Openings openings={this.state.openings}/> }/>


            </div>  
          </Switch>          

           </Router>



            {/* <Contact contactInfo={this.state.contactInfo}></Contact> */}

        </div>)
    }
}

export default App;