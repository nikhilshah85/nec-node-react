import logo from './logo.svg';
import './App.css';
import { getDefaultNormalizer } from '@testing-library/dom';
import Users from './restAPIasync';



//this is not making asyn call in real scence
 const getPostFromJSonPlaceHolder = ()=>
   fetch('https://jsonplaceholder.typicode.com/users').then( (data)=>{ return data.json(); })
                                                     .then( (data) => { console.log(data);                                                       
                                                    });


// const apiFetch = () => {
//   fetch(" https://jsonplaceholder.typicode.com/users")
//     .then((response) => response.json())
//     .then((json) => console.log(json));}

                                                                                                           

const addData=()=>{
  var details={
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({})
  }
  fetch('https://jsonplaceholder.typicode.com/posts/',details).then( (res)=>{ return res.json()} )
                                                              .then( (result)=>{
                                                                  console.log('Data Posted Successfully')
                                                                  console.log(result);} )
                                                               .catch( (err)=>{ console.log(err)} )
                                                               .finally( ()=> { console.log('Thank you')});
}


function App() {
  return (
    <div>
      <button onClick={getPostFromJSonPlaceHolder}> Get Rest Data </button>
      <button onClick={addData}> Post Data </button>

      <Users></Users>
    </div>
  );
}

export default App;
