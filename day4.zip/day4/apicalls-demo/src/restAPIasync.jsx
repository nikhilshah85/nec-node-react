import React from 'react';

class Users extends React.Component{

    constructor(){
        super();
        this.state={
            userdata:[]
        }

        this.getMeUserData = this.getMeUserData.bind(this);
    }


async getMeUserData(){
    const userDetails = await fetch('https://jsonplaceholder.typicode.com/users').then( (dataformat)=>{ return dataformat.json() } )
                                    .then(
                                         (data) => 
                                         {
                                           //  console.log(data);
                                           JSON.stringify(data);
                                             this.setState({userdata:data});
                                             console.log(this.state.userdata);
                                         } 
                                         );

                //do something else here, not with the data which is coming from API
                 //  console.log('Got the below Details');
                 //   console.log(userDetails);
}

    render(){
        return(<div>
                <button onClick={this.getMeUserData}> Get Users (async)</button>

            <div>
                { this.state.userdata.map( (d,i)=>
                    <div>
                         <h1>{ d.name } { d.username}</h1>
                        <p> {d.email}</p>            
                        <p> {d.address.city}</p>
                                

                        <hr/>
                  </div>                  
                )
                }
            </div>

        </div>)
    }
}
export default Users;