import React from 'react'
class Employee extends React.Component
{

    render(){
        return(<div>
            <h2> Employee - Child</h2>
              FirstName :  <h1> {this.props.empName} </h1>
                {/* <h1> Name : {this.state.firstName} {this.state.lastName} </h1> */}

                {/* <button onClick={ this.props.printName() }>Print Name</button> */}
        </div>)
    }

}
export default Employee;

