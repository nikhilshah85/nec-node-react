// import App from './../App';

// export class test extends App{

//     constructor(){
//         super();
//     }
//     render(){
//         return(<div>
//             {/* <h1> State: {this.state.firstName} </h1> */}
//             <h2> Props:{this.props.firstName} </h2>
//         </div>)
//     }

       
// }
