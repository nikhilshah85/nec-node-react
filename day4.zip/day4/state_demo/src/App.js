import logo from './logo.svg';
import './App.css';
import React from 'react';
import Employee from './employee/employee';
import Banking from './banking/banking'
import { test } from './employee/test';

 class App extends React.Component { 

    constructor(){
      super();
      this.state = {
        firstName:'Nikhil',
        lastName:'Shah',
        displayName:()=>{ console.log( this.state.firstName + ' ' + this.state.lastName) },
        getProduct:(pid)=>
        {
           console.log('Details for Product No ' + pid);
           console.log('some data here');
        },
        techList:['React','Node','Redux','Mongo'],
        profile:
        {
          designation:'Trainer',
          ground:'Web',
          qualification:
          { 
            degree:'MCA',
            certification:'Microsoft'
         }
        },
      }
      this.changeMyName = this.changeMyName.bind(this);
    }

    changeMyName()
    {
      this.setState({firstName:'Rahul'});
    }

  render(){
  return (
    <div>
        {/* <h1> Name : {this.state.firstName} {this.state.lastName} </h1>
        <Employee empName={this.state.firstName}></Employee> */}
    {/* <test firstName={this.state.firstName}></test> */}


    {/* <button onClick={this.state.displayName()}> Test</button>
    <Employee empName={this.state.firstName} printName={this.state.displayName}></Employee>
    <button onClick={this.state.getProduct(5)} >  Get Product </button> */}

    <h1> Welcome to State Demo</h1>
    <button onClick={this.changeMyName}>Change Name</button>

    <h1>{this.state.firstName}</h1>

    <hr/>
    <Employee empName={this.state.firstName}></Employee>


    <hr/>
    <Banking employeeName={this.state.firstName}></Banking>
    </div>
  );
  }
}

export default App;
