import React from 'react'
class Banking extends React.Component
{

    render(){
        return(<div>
            <h2> Banking - Child</h2>
              FirstName :  <h1> {this.props.employeeName} </h1>
             
        </div>)
    }

}
export default Banking;

