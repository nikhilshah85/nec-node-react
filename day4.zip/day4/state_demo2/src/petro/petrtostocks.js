import { getDefaultNormalizer } from '@testing-library/dom';
import React, { Component } from 'react';
class PetroStock extends Component
{
     stockDetails=[];
    constructor(props){
        super(props);
         this.stockDetails = this.props.showStocks();
    }
    render(){

          

        return(<div>
            <h1> List of Petro Stocks </h1>

            <table>
        {this.stockDetails.map( (s,i)=> <tr>
                      <td> {s.stockId} </td>
                      <td> {s.stockName} </td>
                      <td> {s.stockCategory} </td>
                      <td> {s.stockPrice} </td>

        </tr>     )}
      </table>

         <button onClick={this.props.showStocks()}>Get Petro Stocks</button>
        </div>)
    }

}

export default PetroStock; 