import logo from './logo.svg';
import './App.css';
import React from 'react'
import PetroStock from './petro/petrtostocks';
import ReactDOM from 'react-dom';
import RHooks from './reactHooks';

class App extends React.Component
{

  constructor(){
    super();
    this.state={
      stockInfo:[{stockId:101,stockName:'RIL',stockCategory:'Petro',stockPrice:2100},
      {stockId:102,stockName:'TCS',stockCategory:'IT',stockPrice:2100},
      {stockId:103,stockName:'Wipro',stockCategory:'IT',stockPrice:2100},
      {stockId:104,stockName:'Cipla',stockCategory:'Pharma',stockPrice:2100},
      {stockId:105,stockName:'IOC',stockCategory:'Petro',stockPrice:2100},
      {stockId:106,stockName:'BPCL',stockCategory:'Petro',stockPrice:2100}
    ],
    friends:['Priya','Riya','Jia'],
    getPetroStocks:()=>{
        let pStock = [];     
      for (let i = 0; i < this.state.stockInfo.length; i++) {
          if(this.state.stockInfo[i].stockCategory == 'Petro')
          {
            pStock.push(this.state.stockInfo[i]);
          }        
          console.log(pStock);
      }
       return pStock;
      },
    getITStocks:()=>{ return 'filter and return the IT stocks'},
    getPharmaStocks:()=>{ return 'filter and return the Pharma stocks'},
    getStockInfo:(stockCategory)=>{ return 'values based on ' + stockCategory}
    }
    this.addNewFriend = this.addNewFriend.bind(this);
  }

  addNewFriend(){
    let oldList  = this.state.friends;
    // let newVal = document.getElementById('txtNewFriend').value;
    let newVal = ReactDOM.findDOMNode(this.refs.txtNewFriend).value;
    oldList.push(newVal);
    this.setState({friends:oldList});
  }

  render(){
    return(<div>
      <h1> I am  the APP Component</h1>
      <RHooks></RHooks>

      {/* <table>
        {this.state.stockInfo.map( (s,i)=> <tr>
                      <td> {s.stockId} </td>
                      <td> {s.stockName} </td>
                      <td> {s.stockCategory} </td>
                      <td> {s.stockPrice} </td>

        </tr>     )}
      </table>

      <ul>
        {this.state.friends.map(  (f)=><li> {f} </li>  )}
      </ul>
      {/* <input type="text" placeholder="Enter New Friend Name" id="txtNewFriend"/> */}
      {/* <input type="text" placeholder="Enter New Friend Name" ref="txtNewFriend"/>
      <button onClick={this.addNewFriend}>Add Friend</button>

      <hr/>
      <PetroStock showStocks={this.state.getPetroStocks}></PetroStock> */}
    </div>)
  }

}

export default App;
