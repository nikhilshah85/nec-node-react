import React from 'react';
import {useRef} from 'react';

function RHooks()
{

   function myAddFunction()
    {
        if(firstName.current)
        {
        console.log(firstName.current.value);
        }

        if(lastName.current)
        {
        console.log(lastName.current.value);
        }
        
        if(salary.current)
        {
        console.log(salary.current.value);
        }
        if(designation.current)
        {
        console.log(designation.current.value);
        }
        if(salary.current)
        {
        console.log(salary.current.value);
        }
    }
    
   
    const firstName=useRef(null);
    const lastName=useRef(null);
    const salary=useRef(null);
    const designation=useRef(null);
    const city=useRef(null);
        return(<div>

            <input type="text" placeholder="Name" ref={firstName} />
            <input type="text" placeholder="Last Name" ref={lastName} />
            <input type="text" placeholder="Salary" ref={salary}/>
            <input type="text" placeholder="Designation" ref={designation} />
            <input type="text" placeholder="City" ref={city} />
            <button onClick={myAddFunction}> Value </button>

            </div>)
    
}

 export default RHooks;