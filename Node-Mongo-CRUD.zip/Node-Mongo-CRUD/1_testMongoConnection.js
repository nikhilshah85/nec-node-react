var mongoConnection = require('mongodb').MongoClient;
var con = 'mongodb://127.0.0.1:27017/movies';

mongoConnection.connect(con,function(errMessage,database){

    if(errMessage) 
    {
        console.log(errMessage);
        throw errMessage;
    }
    console.log('Connected To Movies Database at Mongo');

    database.close();
})


//you want to write this code in rest api, express to process the data