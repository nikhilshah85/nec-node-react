var mongoConnection = require('mongodb').MongoClient;
var con = 'mongodb://127.0.0.1:27017/movies';


mongoConnection.connect(con,function(errMessage,dbref){

    if(errMessage) 
    {
        console.log(errMessage);
        throw errMessage;
    }
    var mydb = dbref.db("movies");
    var deleteMovie = {_id:101};

    mydb.collection("moviesCollection").deleteOne(deleteMovie,function(deleteErr,success){
        if(deleteErr){ console.log(deleteErr.message); }
        else{ console.log(success.deletedCount + " Deleted Successfully"); }

    })
dbref.close();
})