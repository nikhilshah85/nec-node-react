var mongoConnection = require('mongodb').MongoClient;
var con = 'mongodb://127.0.0.1:27017/movies';


mongoConnection.connect(con,function(errMessage,dbref){

    if(errMessage) 
    {
        console.log(errMessage);
        throw errMessage;
    }

    var db = dbref.db("movies");

// Finds the first document by default
    // db.collection("moviesCollection").findOne({},function(err,doc){
    //     if(err){ console.log(err.message); }
    //     else{ console.log(doc); }
    // })

//find by ID or any property you give in first parameter
    // db.collection("moviesCollection").findOne({_id:107},function(err,doc){
    //     if(err){ console.log(err.message); }
    //     else{ console.log(doc.movieName); }
    // })

//Find all the documents
    db.collection("moviesCollection").find({}).toArray(function(errFind,docs){
        if(errFind){ console.log(errFind.errMessage); }
        else{ console.log(docs[3].movieName); }
    });
    dbref.close();
});