var mongoConnection = require('mongodb').MongoClient;
var con = 'mongodb://127.0.0.1:27017/movies';


mongoConnection.connect(con,function(errMessage,dbref){

    if(errMessage) 
    {
        console.log(errMessage);
        throw errMessage;
    }

    var db = dbref.db("movies");
    var oldData = {"movieName" : "Titanic"};
    var newData = { $set: {"movieName" : "New Titanic","movieType":"More Scarry","releaseYear":2016}};

    db.collection("moviesCollection").updateMany(oldData,newData,function(uErr,eRes){
        if(uErr){ console.log(uErr.message); }
        else{ console.log('Movie Updated'); }
    })

    dbref.close();
})