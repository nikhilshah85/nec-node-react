var mongoConnection = require('mongodb').MongoClient;
var con = 'mongodb://127.0.0.1:27017/movies';
mongoConnection.connect(con,function(errMessage,dbref){

    if(errMessage) 
    {
        console.log(errMessage);
        throw errMessage;
    }
    console.log('Connected To Movies Database at Mongo');

    var movieDB = dbref.db('movies');
    var newMovie = { _id:106, movieName:'Aqua man', movieType:'Fiction',releaseYear:2019};
    var newMovie1 = { _id:107, movieName:'Titanic', movieType:'Fiction',releaseYear:2019};
    var newMovie2 = { _id:108, movieName:'Happy Endings', movieType:'Fiction',releaseYear:2019};
    var newMovie3 = { _id:109, movieName:'No strings attached', movieType:'Fiction',releaseYear:2019};

    allMovies = [newMovie,newMovie1,newMovie2,newMovie3];

    movieDB.collection('moviesCollection').insertMany(allMovies,function(err,result){
        if(err) 
        {
            //  console.log(err); 
            console.log('Error, _id shoud be unique');
        }
        else{ 
            // console.log('New Movie Added'); 
            console.log(result.insertedCount + " Movies Added");


        }

    })
    dbref.close();
})