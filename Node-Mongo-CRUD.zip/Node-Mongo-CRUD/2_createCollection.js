var mongoConnection = require('mongodb').MongoClient;
var con = 'mongodb://127.0.0.1:27017/movies';
mongoConnection.connect(con,function(errMessage,dbref){

    if(errMessage) 
    {
        console.log(errMessage);
        throw errMessage;
    }
    console.log('Connected To Movies Database at Mongo');

    var movieDB = dbref.db('movies');
    var newMovie = { _id:101, movieName:'Aqua man', movieType:'Fiction',releaseYear:2019};

    movieDB.collection('moviesCollection').insertOne(newMovie,function(err,result){
        if(err) { console.log(err); }
        else{ console.log('New Movie Added'); }

    })
    dbref.close();
})